const Legend = () => {
  return (
    <div className="absolute top-4 right-4 bg-white bg-opacity-80 p-2 rounded shadow">
      <h3 className="font-bold text-black mb-2">Legend</h3>
      <div className="flex items-center mb-1">
        <div className="w-4 h-4 bg-yellow-400 rounded-full mr-2"></div>
        <span className="text-black text-sm">Shuttle</span>
      </div>
      <div className="flex items-center mb-1">
        <div className="w-4 h-4 bg-blue-500 rounded-full mr-2"></div>
        <span className="text-black text-sm">Stop</span>
      </div>
      <div className="flex items-center">
        <div className="w-4 h-1 bg-red-500 mr-2"></div>
        <span className="text-black text-sm">Route</span>
      </div>
    </div>
  )
}

export default Legend

