const ShuttleInfo = ({ shuttles, onShuttleClick }) => {
  return (
    <div>
      {shuttles.map((shuttle, index) => (
        <div
          key={index}
          className="mb-4 p-4 bg-green-800 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 cursor-pointer"
          onClick={() => onShuttleClick(shuttle)}
        >
          <h2 className="text-xl font-semibold mb-2 text-yellow-400">{shuttle.name}</h2>
          <p className="text-sm mb-1">
            <span className="font-medium">Current Location:</span> {shuttle.currentLocation}
          </p>
          <p className="text-sm mb-1">
            <span className="font-medium">Next Stop:</span> {shuttle.nextStop}
          </p>
          <p className="text-sm">
            <span className="font-medium">Estimated Arrival:</span> {shuttle.estimatedArrival}
          </p>
        </div>
      ))}
    </div>
  )
}

export default ShuttleInfo

