export const shuttleStops = [
  { name: "Brunei", latitude: 6.6741, longitude: -1.5728 },
  { name: "Katanga", latitude: 6.6752, longitude: -1.5739 },
  { name: "Prempeh Library", latitude: 6.673, longitude: -1.5746 },
  { name: "Penticost Bus Stop", latitude: 6.6718, longitude: -1.5757 },
  { name: "KSB", latitude: 6.6707, longitude: -1.5768 },
  { name: "Commercial Area", latitude: 6.6763, longitude: -1.572 },
  { name: "Republic Hall Junction", latitude: 6.6748, longitude: -1.5733 },
  { name: "Unity Hall Junction", latitude: 6.6735, longitude: -1.5745 },
  { name: "Casley Hayford Junction", latitude: 6.6723, longitude: -1.5756 },
]

export const shuttleRoutes = [
  {
    name: "Brunei-KSB",
    color: "#FF0000",
    coordinates: [
      [-1.5728, 6.6741],
      [-1.5739, 6.6752],
      [-1.5746, 6.673],
      [-1.5757, 6.6718],
      [-1.5768, 6.6707],
    ],
  },
  {
    name: "Commercial-KSB",
    color: "#00FF00",
    coordinates: [
      [-1.572, 6.6763],
      [-1.5733, 6.6748],
      [-1.5745, 6.6735],
      [-1.5768, 6.6707],
    ],
  },
]

