import { shuttleStops } from "./shuttleData"

const bruneKsbStops = ["Brunei", "Katanga", "Prempeh Library", "Penticost Bus Stop", "KSB"]
const commercialKsbStops = ["Commercial Area", "Republic Hall Junction", "Unity Hall Junction", "KSB"]

const calculateShuttlePosition = (startTime: Date, currentTime: Date, stops: string[], interval: number) => {
  const elapsedMinutes = (currentTime.getTime() - startTime.getTime()) / 60000
  const cycleMinutes = stops.length * interval
  const currentCycleMinutes = elapsedMinutes % cycleMinutes
  const currentStopIndex = Math.floor(currentCycleMinutes / interval)
  const nextStopIndex = (currentStopIndex + 1) % stops.length
  const minutesToNextStop = interval - (currentCycleMinutes % interval)

  const currentLocation = stops[currentStopIndex]
  const nextStop = stops[nextStopIndex]
  const estimatedArrival = `${Math.round(minutesToNextStop)} minutes`

  const currentStopData = shuttleStops.find((stop) => stop.name === currentLocation)
  const nextStopData = shuttleStops.find((stop) => stop.name === nextStop)

  return {
    currentLocation,
    nextStop,
    estimatedArrival,
    latitude: currentStopData ? currentStopData.latitude : 0,
    longitude: currentStopData ? currentStopData.longitude : 0,
    nextLatitude: nextStopData ? nextStopData.latitude : 0,
    nextLongitude: nextStopData ? nextStopData.longitude : 0,
  }
}

export const calculateShuttlePositions = (currentTime: Date) => {
  const shuttles = []
  const startTime = new Date(currentTime)
  startTime.setHours(7, 30, 0, 0)

  for (let i = 1; i <= 2; i++) {
    const shuttleStartTime = new Date(startTime.getTime() + (i - 1) * 20 * 60000)
    shuttles.push({
      name: `Shuttle ${i}`,
      route: "Brunei-KSB",
      ...calculateShuttlePosition(shuttleStartTime, currentTime, bruneKsbStops, 30),
    })
  }

  for (let i = 3; i <= 5; i++) {
    const shuttleStartTime = new Date(startTime.getTime() + (i - 3) * 20 * 60000)
    shuttles.push({
      name: `Shuttle ${i}`,
      route: "Commercial-KSB",
      ...calculateShuttlePosition(shuttleStartTime, currentTime, commercialKsbStops, 30),
    })
  }

  return shuttles
}

