"use client"

import { useEffect, useState, useRef } from "react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"
import ShuttleInfo from "./components/ShuttleInfo"
import Legend from "./components/Legend"
import SearchBar from "./components/SearchBar"
import { calculateShuttlePositions } from "./utils/shuttleLogic"
import { shuttleStops, shuttleRoutes } from "./utils/shuttleData"

mapboxgl.accessToken = "pk.eyJ1IjoibmlpYW11MjgiLCJhIjoiY203ZmtqZ242MGx4czJpcjUxY2YxMm93NyJ9.Dqmn3ZZ765bK4HcyTnasGg"

export default function Home() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [shuttleData, setShuttleData] = useState([])
  const [selectedShuttle, setSelectedShuttle] = useState(null)
  const mapContainer = useRef(null)
  const map = useRef(null)
  const shuttleMarkers = useRef({})

  useEffect(() => {
    if (map.current) return // initialize map only once
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/dark-v10",
      center: [-1.5734, 6.6745],
      zoom: 14,
    })

    map.current.on("load", () => {
      // Add shuttle routes
      shuttleRoutes.forEach((route, index) => {
        map.current.addSource(`route-${index}`, {
          type: "geojson",
          data: {
            type: "Feature",
            properties: {},
            geometry: {
              type: "LineString",
              coordinates: route.coordinates,
            },
          },
        })

        map.current.addLayer({
          id: `route-${index}`,
          type: "line",
          source: `route-${index}`,
          layout: {
            "line-join": "round",
            "line-cap": "round",
          },
          paint: {
            "line-color": route.color,
            "line-width": 3,
          },
        })
      })

      // Add markers for shuttle stops
      shuttleStops.forEach((stop) => {
        new mapboxgl.Marker({ color: "#3498db" })
          .setLngLat([stop.longitude, stop.latitude])
          .setPopup(new mapboxgl.Popup().setHTML(`<h3>${stop.name}</h3>`))
          .addTo(map.current)
      })
    })

    // Ensure the map resizes correctly
    window.addEventListener("resize", () => {
      map.current.resize()
    })
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date()
      setCurrentTime(now)
      const newShuttleData = calculateShuttlePositions(now)
      setShuttleData(newShuttleData)

      // Update shuttle markers
      newShuttleData.forEach((shuttle, index) => {
        if (!shuttleMarkers.current[shuttle.name]) {
          const el = document.createElement("div")
          el.className = "shuttle-marker"
          el.innerHTML = `<div class="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center text-xs font-bold text-black">${index + 1}</div>`

          shuttleMarkers.current[shuttle.name] = new mapboxgl.Marker(el)
            .setLngLat([shuttle.longitude, shuttle.latitude])
            .addTo(map.current)
        } else {
          shuttleMarkers.current[shuttle.name].setLngLat([shuttle.longitude, shuttle.latitude])
        }
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const handleShuttleClick = (shuttle) => {
    setSelectedShuttle(shuttle)
    map.current.flyTo({
      center: [shuttle.longitude, shuttle.latitude],
      zoom: 15,
    })
  }

  const handleSearch = (searchTerm) => {
    // Implement search functionality
    console.log("Searching for:", searchTerm)
  }

  return (
    <div className="flex flex-col h-screen bg-knust-blue text-white">
      <header className="bg-green-800 p-4 text-center">
        <h1 className="text-3xl font-bold text-yellow-400">KNUST Shuttle Tracker</h1>
      </header>
      <div className="flex flex-1 overflow-hidden">
        <aside className="w-1/4 p-4 overflow-y-auto bg-green-900">
          <p className="mb-4 text-yellow-400">{currentTime.toLocaleString()}</p>
          <SearchBar onSearch={handleSearch} />
          <ShuttleInfo shuttles={shuttleData} onShuttleClick={handleShuttleClick} />
        </aside>
        <main className="flex-1 relative">
          <div ref={mapContainer} className="absolute inset-0" />
          <Legend />
          <div className="absolute bottom-2 left-2 text-sm text-white bg-black bg-opacity-50 p-1 rounded">
            Built by Nii Amu Ankrah
          </div>
        </main>
      </div>
      {selectedShuttle && (
        <div className="absolute bottom-4 left-1/4 right-4 bg-green-800 p-4 rounded-lg shadow-lg">
          <h2 className="text-xl font-bold mb-2">{selectedShuttle.name}</h2>
          <p>Current Location: {selectedShuttle.currentLocation}</p>
          <p>Next Stop: {selectedShuttle.nextStop}</p>
          <p>ETA: {selectedShuttle.estimatedArrival}</p>
        </div>
      )}
    </div>
  )
}

